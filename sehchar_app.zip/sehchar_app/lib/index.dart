// Export pages
export '/login/login_widget.dart' show LoginWidget;
export '/home/home_widget.dart' show HomeWidget;
export '/enterypage/enterypage_widget.dart' show EnterypageWidget;
export '/pages/angry/angry1/angry1_widget.dart' show Angry1Widget;
export '/pages/angry/angry2/angry2_widget.dart' show Angry2Widget;
export '/pages/angry/angry3/angry3_widget.dart' show Angry3Widget;
export '/pages/angry/angry7/angry7_widget.dart' show Angry7Widget;
export '/pages/angry/angry4/angry4_widget.dart' show Angry4Widget;
export '/pages/angry/angry5/angry5_widget.dart' show Angry5Widget;
export '/pages/angry/angry6/angry6_widget.dart' show Angry6Widget;
export '/pages/angry/angry8/angry8_widget.dart' show Angry8Widget;
export '/pages/angry/angry10/angry10_widget.dart' show Angry10Widget;
export '/pages/angry/angry9/angry9_widget.dart' show Angry9Widget;
export '/pages/angry/tasksanger/tasksanger_widget.dart' show TasksangerWidget;
export '/pages/anxious/anxious1/anxious1_widget.dart' show Anxious1Widget;
export '/pages/anxious/anxious2/anxious2_widget.dart' show Anxious2Widget;
export '/pages/anxious/anxious3/anxious3_widget.dart' show Anxious3Widget;
export '/pages/anxious/anxious4/anxious4_widget.dart' show Anxious4Widget;
export '/pages/anxious/anxious5/anxious5_widget.dart' show Anxious5Widget;
export '/pages/anxious/anxious6/anxious6_widget.dart' show Anxious6Widget;
export '/pages/anxious/anxious7/anxious7_widget.dart' show Anxious7Widget;
export '/pages/anxious/anxious8/anxious8_widget.dart' show Anxious8Widget;
export '/pages/anxious/anxious9/anxious9_widget.dart' show Anxious9Widget;
export '/pages/anxious/anxious10/anxious10_widget.dart' show Anxious10Widget;
export '/pages/anxious/anxioustask/anxioustask_widget.dart'
    show AnxioustaskWidget;
export '/pages/depressed/depressed1/depressed1_widget.dart'
    show Depressed1Widget;
export '/pages/depressed/depressed2/depressed2_widget.dart'
    show Depressed2Widget;
export '/pages/depressed/depressed3/depressed3_widget.dart'
    show Depressed3Widget;
export '/pages/depressed/depressed4/depressed4_widget.dart'
    show Depressed4Widget;
export '/pages/depressed/depressed5/depressed5_widget.dart'
    show Depressed5Widget;
export '/pages/depressed/depressed6/depressed6_widget.dart'
    show Depressed6Widget;
export '/pages/depressed/depressed7/depressed7_widget.dart'
    show Depressed7Widget;
export '/pages/depressed/depressed8/depressed8_widget.dart'
    show Depressed8Widget;
export '/pages/depressed/depressed9/depressed9_widget.dart'
    show Depressed9Widget;
export '/pages/depressed/depressed10/depressed10_widget.dart'
    show Depressed10Widget;
export '/pages/depressed/taskdepress/taskdepress_widget.dart'
    show TaskdepressWidget;
export '/pages/anxious/anxioustask1/anxioustask1_widget.dart'
    show Anxioustask1Widget;
export '/pages/anxious/anxioustask2/anxioustask2_widget.dart'
    show Anxioustask2Widget;
export '/pages/anxious/anxioustask3/anxioustask3_widget.dart'
    show Anxioustask3Widget;
export '/pages/anxious/anxioustask4/anxioustask4_widget.dart'
    show Anxioustask4Widget;
export '/pages/anxious/anxioustask5/anxioustask5_widget.dart'
    show Anxioustask5Widget;
export '/details24_quiz_page/details24_quiz_page_widget.dart'
    show Details24QuizPageWidget;
export '/details25_quiz_page/details25_quiz_page_widget.dart'
    show Details25QuizPageWidget;
export '/gender/gender_widget.dart' show GenderWidget;
export '/task/task_widget.dart' show TaskWidget;
export '/professionalhelp/professionalhelp_widget.dart'
    show ProfessionalhelpWidget;
export '/pages/angry/tasksanger1/tasksanger1_widget.dart'
    show Tasksanger1Widget;
export '/pages/angry/tasksanger2/tasksanger2_widget.dart'
    show Tasksanger2Widget;
export '/pages/angry/tasksanger3/tasksanger3_widget.dart'
    show Tasksanger3Widget;
export '/pages/angry/tasksanger4/tasksanger4_widget.dart'
    show Tasksanger4Widget;
export '/pages/angry/tasksanger5/tasksanger5_widget.dart'
    show Tasksanger5Widget;
export '/pages/depressed/taskdepressed1/taskdepressed1_widget.dart'
    show Taskdepressed1Widget;
export '/pages/depressed/taskdepressed2/taskdepressed2_widget.dart'
    show Taskdepressed2Widget;
export '/pages/depressed/taskdepressed3/taskdepressed3_widget.dart'
    show Taskdepressed3Widget;
export '/pages/depressed/taskdepressed5/taskdepressed5_widget.dart'
    show Taskdepressed5Widget;
export '/pages/depressed/taskdepressed4/taskdepressed4_widget.dart'
    show Taskdepressed4Widget;
export '/mentalhealth/mentalhealth_widget.dart' show MentalhealthWidget;
export '/signin/signin_widget.dart' show SigninWidget;
